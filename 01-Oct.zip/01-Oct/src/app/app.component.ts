import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template:`<h1>{{title}}</h1>
  //           <h4>{{12+23}}</h4>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularApp2021';
  firstName="Swati";
  lastName="Bhirud";
  email="swati.bhirud@atos.net";

  updateName(){
    this.firstName="Manisha";
    this.lastName="Mane";
  }
}
