import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {

flag=true;
UserName="swati1";
password="ang@123";
colors=['Red','Blue','Green','Orange'];
color="R";

  constructor() { }

  ngOnInit(): void {
  }

}
