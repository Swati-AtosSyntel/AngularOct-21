import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { EmployeeComponent } from './employee/employee.component';
import { GenderPipe } from './gender.pipe';
import { EmployeecountComponent } from './employeecount/employeecount.component';

@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    EmployeeComponent,
    GenderPipe,
    EmployeecountComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
